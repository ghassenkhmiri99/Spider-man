const path = require('path');

const date = (req, res, next) => {
    let date = new Date();
    let day = date.getDay();
    let h = date.getHours();
    if ((day >= 1 && day <= 5) && (h >= 9 && h <= 17)) {
    } else {
        const filePath = path.join(__dirname, '../public/', 'outOff.html');
        res.sendFile(filePath);
    }
    next();
};

module.exports = date;