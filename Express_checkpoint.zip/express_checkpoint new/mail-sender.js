const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 465,
  secure: true,
  auth: {
    user: 'ghassenkhmiri18@gmail.com',
    pass: 'gtlz binq vhcb nozl'
  },
  tls: {
    rejectUnauthorized: false
  }
});

const sendMail = (to, subject, text, callback) => {
    const mailOptions = {
        from: 'ghassenkhmiri18@gmail.com',
        to: 'ghassenkhmiri18@gmail.com',
        subject: subject,
        text: `${text} ${to}` 
    };

    console.log('Sending email to:', to);
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error('Error sending email:', error);
            return callback(error, null);
        }
        console.log('Email sent:', info.response);
        callback(null, info.response);
    });
};

module.exports = sendMail;